"""
Concatenate some strings into a longer
string and print out the result
"""

word1 = "tree"
word2 = "branch"
word3 = "leaf"

sentence = word1 + Word2 + word3

print(sentence)
