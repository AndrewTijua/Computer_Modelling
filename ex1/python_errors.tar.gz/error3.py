"""
Return the square of a user-given number
"""

mynum = input("An integer number, please: ")

print("The square of your number is:")
print(mynum**2)
