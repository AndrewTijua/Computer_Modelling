"""
Print out a series of integers
"""

nmax = 10

for n in range(nmax)
  print("The number is " + n)
